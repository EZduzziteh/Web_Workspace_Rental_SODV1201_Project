const path = require("path");
const express = require("express");
const sqlite3 = require("sqlite3");
const http = require("http");
const fs = require("fs");

const app = express();

/// Call Database ///
const db = new sqlite3.Database(__dirname + "/rentalProperty.db", sqlite3.OPEN_READWRITE, (err) => {
    if (err) return console.error(err.message)
    console.log("Connected Successfully.");
})

// db.run('CREATE TABLE users (first, last, email)')
// /// Creating Tables ///
// db.run("CREATE TABLE Propertys (Property_ID int NOT NULL PRIMARY KEY, Province varchar(2), City varchar(50), Postal_Code varchar(10), Address varchar(50), Parking varchar(5), Public_Transport varchar(5))");
// db.run("CREATE TABLE Workspaces (Workspace_ID int NOT NULL PRIMARY KEY, Property_ID int NOT NULL, Rent int, Workspace varchar(50), Smoking bit, Capacity int, Lease_Term varchar(50), Availability varchar(5), Owner varchar(50), Neighborhood varchar(50), Square_Feet int)");
// db.run("CREATE TABLE Companys (Company_ID int NOT NULL PRIMARY KEY, Workspace_ID int NOT NULL, Name varchar(50), Company_Phone varchar(50))");
// db.run("CREATE TABLE Employees (Employee_ID INTEGER PRIMARY KEY AUTOINCREMENT, Company_ID INTEGER NOT NULL, Name varchar(50), Email varchar(50), Phone varchar(50), Position varchar(50))");

// /// Populating Database ///
// db.run("INSERT INTO Propertys (Property_ID, Province, City, Postal_Code, Address, Parking, Public_Transport) VALUES (1,'AB','Calgary','T3G4L6','222 22 ave nw','TRUE','FALSE'),(2,'AB','Edmonton','T9HI9L','197 1st st','TRUE','TRUE'),(3,'BC','Vancouver','H6HI7U','13 Village st', 'FALSE', 'TRUE'),(4,'AB','Calgary','T5H4L7','256 22 ave nw','TRUE','FALSE')");
// db.run("INSERT INTO Workspaces (Workspace_ID, Property_ID, Rent, Workspace, Smoking, Capacity, Lease_Term, Availability, Owner, Neighborhood, Square_Feet) VALUES (1,1,500,'Open Area','FALSE',2,'Weekly','TRUE','Joel','Arbour Lake',1200),(2,2,2600,'Meeting Rooms','FALSE',4,'Weekly','TRUE','None','Hillcrest',1400),(3,3,700,'Office Rooms','FALSE',8,'Weekly','TRUE', 'None', 'Oceanside', 800),(4,4,800,'Open Area','FALSE',1,'Mounthly','TRUE','Evan','Citadel',2300),(5,4,900,'Office Rooms','FALSE',8,'Monthly','FALSE','Evan','Citadel',2100)");
// db.run("INSERT INTO Companys (Company_ID, Workspace_ID, Name, Company_Phone) VALUES (1,1,'My.TECH','4032081330'),( 2,2,'TLE','4039929639'),(3,3,'Office Together','4039219638'),(4,4,'Travis and Associates','4037775555'),(5,4,'Travis and Associates','4039929639')");
// db.run("INSERT INTO Employees	(Employee_ID, Company_ID, Fname, Lname, Email, Phone, Position)VALUES (1,1,'Joel','Mcarthor',	'fakeemail1@gmail.com',	'4031234567',	'Owner'),(2,2,'Sasha','Greene','fakeemail2@gmail.com','4030987654','Employee'),(3,3,'Paul','Kho','fakeemail3@gmail.com','4030198374','Employee'),(4,4,'Travis','Kaur','fakeemail4@gmail.com','4030987654','Employee'),(5,4,'Evan','MacLean','e.maclean975@mybvc.ca','4039929639','Owner')");

//Middleware
app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({extended : false}));

const bodyParser = require('body-parser');

app.post('/signup', (req, res) => {
    let html = path.join(__dirname, '/coworkerworkspacedetails.html');
    const data = req.body
    console.log(data)
    const query = `INSERT INTO Employees (Name, Email, Company_ID, Phone, Position) VALUES (?, ?, ?, ?, ?)`
    db.run(query, [data.name, data.email, 1, data.phone, data.role], (err) => {
    if (err) console.log(err)
    console.log('A new row has been created')
    })
    res.redirect('/coworker_listings')
    
})

/// Coworker Listings Page ///
app.get('/coworker_listings', function(req, res) {
    let html = path.join(__dirname, '/coworkerworkspacedetails.html');
    res.sendFile(html)
});

app.get('/get-listings', (req, res) => {
    let data = [];
    db.all('SELECT * FROM Workspaces as w JOIN Propertys as p WHERE w.Property_ID = p.Property_ID ', [], (err, rows) => {
    if (err) console.log(err)
    if (!rows) return
    rows.forEach(row => {
       data.push(row)
    })
    res.json({data: data})
    })
})

/// Coworker Create New ///
app.post('/coworker_listings', async (req, res) => {
    const data = req.body
    console.log(data)
    const query = `INSERT INTO Workspaces (Rent, Lease_Term, Public_Transit, Parking, Smoking, Square_Feet, Capacity, Address, Neighborhood) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    db.run(query, [data.rent, data.lease_Term, data.public_Transit, data.parking, data.smoking, data.square_Feet, data.capacity, data.address, data.neighborhood], (err) => {
        console.log('A new row has been created')
    })
    res.sendStatus(200)
}) 

/// Owner Listings Page ///
app.get('/owner_listings', async (req, res) => {
    // let html = path.join(__dirname, '/ownercoworkerworkspacedetails.html');
    // let data;
    // db.all('SELECT * FROM Workspaces', [], (err, rows) => {
    //     if(rows) return
    //     rows.forEach(row => {
    //         console.log(rows)
    //     }) 
    //     data.json({html: html.toString(), data: "data"})
    // })
})

/// Coworker Create New ///
app.post('/owner_listings', async (req, res) => {
    const data = req.body
    console.log(data)
    const query = `INSERT INTO Workspaces (Rent, Lease_Term, Public_Transit, Parking, Smoking, Square_Feet, Capacity, Address, Neighborhood) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    db.run(query, [data.rent, data.lease_Term, data.public_Transit, data.parking, data.smoking, data.square_Feet, data.capacity, data.address, data.neighborhood], (err) => {
        console.log('A new row has been created')
    })
    res.sendStatus(200)
}) 


app.post('/owner_listings', async (req, res) => {
    const data = req.body
    console.log(data)
    const query2 = `UPDATE Propertys (Public_Transport, Parking, Address) VALUES(?,?,?)`
    const query1 = `UPDATE Workspaces (Rent, Lease_Term, Smoking, Square_Feet, Capacity, Neighborhood) VALUES(?,?,?,?,?,?,?)`;
    db.run(query1, [data.rent, data.lease_Term, data.smoking, data.square_Feet, data.capacity, data.address, data.neighborhood], (err) => {
        console.log('Updated existing row.')
    })
    db.run(query2, [data.public_Transit, data.parking], (err) => {
        console.log('Updated existing row.')
    })

})

app.post('/coworker_listings', async (req, res) => {
    const data = req.body
    console.log(data)
    const query = `INSERT INTO Workspaces (Rent, Lease_Term, Public_Transit, Parking, Smoking, Square_Feet, Capacity, Address, Neighborhood) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    db.run(query, [data.rent, data.lease_Term, data.public_Transit, data.parking, data.smoking, data.square_Feet, data.capacity, data.address, data.neighborhood], (err) => {
        console.log('A new row has been created')
    })
    res.sendStatus(200)
}) 


var server = app.listen(3000, () => {
    console.log("Connected to Port ", server.address().port, " Successfully.")
})