// SODV 1201 Term Project 
// Javascript, Node, API and REST API 
// Sasha and Evan
$(document).ready(function() {
let display = 0;
let workspaces; 

function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}
function validateForm() {

    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var role = document.Form.role.value;

    var namErr= emailErr = mobileErr =roleErr=true;

    if (name=="")
    {
        printError("nameErr", "PLEASE ENTER YOUR NAME");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[a-zA-Z\s]+$/;
        if(regex.test(name)===false){
            printError("nameErr","PLEASE ENTER A VALID NAME");
            var elem=document.getElementById("name");

        }else{
            namErr=false;
            printError("nameErr","");
            var elem=document.getElementById("name");
        }
    }

    
    if (email=="")
    {
        printError("emailErr", "PLEASE ENTER YOUR EMAIL ADDRESS");
        var elem=document.getElementById("email");
        
    }
    else{
        var regex=/^S+@\S+\.\S+$/;
        if(regex.test(email)===false){
            printError("emailErr","PLEASE ENTER A VALId EMAIL ADDRESS");
            var elem=document.getElementById("email");

        }else{
            namErr=false;
            printError("emailErr","");
            var elem=document.getElementById("email");
        }
    }




    if (mobile-number=="")
    {
        printError("mobileErr", "PLEASE ENTER YOUR MOBILE NUMBER");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[1-9]\d{9}$/;
        if(regex.test(mobile)=== false){
            printError("mobileErr","PLEASE ENTER A VALID 10 DIGIT MOBILE NUMBER");
            var elem=document.getElementById("mobile");

        }else{
            mobileErr=false;
            printError("mobileErr","");
            var elem=document.getElementById("mobile");
        }
    }

    
    if (role="")
    {
        printError("roleErr", "PLEASE ENTER YOUR ROLE");
        var elem=document.getElementById("ole");
        
    }else{
        printError("roleErr","");
            roleErr=false;
            var elem=document.getElementById("role");
        }
    

        if ((nameErr|| emailErr||mobileErr||roleErr)== true){
            return false;
        }

};
 ////////////////////////////////////////////////////////////
    // User Story 2 Display Listings
///////////////////////////////////////////////////////////

// Button display next listing.
$('#next').click(() => {
    displayNext()
})
$('#prev').click(() => {
    displayPrev()
})


function displayNext() {
    if(display > workspaces.length -2) return 
    display++
    console.log('Display', display)
    createListing(display)
};
function displaySpecific(index) {
    if(display > workspaces.length -2) return 
    
    createListing(index)
    console.log(index)
};
// Display Current Value
function displayCurrent(){
    if(display > workspaces.length -2) return 
    createListing(display)
    console.log(display)
}
// Button display prev listing.
function displayPrev() {
    if(display < 1) return 
    display--
    createListing(display)
    console.log(display)
};

 ////////////////////////////////////////////////////////////
    // User Story 2 Display Listing 
///////////////////////////////////////////////////////////

// Ablility to edit displayed listings.
function createListing(index) { 
    console.log('This is in createListing function', workspaces, index)
    $("#displayDiv").empty();
    let row = `
        <div class="H1-1">
            <div class="H1-4">
            <p class="H1">Price:
                <p id = two class="H1-2">${workspaces[index].Rent}</p>
            </p>
            </div>
            <div class="H1-4">
            <p class="H1">Term:
                <p id = three class="H1-2">${workspaces[index].Lease_Term}</p>
            </p>
            </div>
            <div class="H1-4">
                <p class="H1">Public Transport:
                    <p id = four class="H1-2">${workspaces[index].Public_Transport}</p>
                </p>
            </div> 
            <div class="H1-4">
            <p class="H1">Parking:
                <p id = five class="H1-2">${workspaces[index].Parking}</p>
            </p>
            </div>
            <div class="H1-4">    
            <p class="H1">Smoking:
                <p id = six class="H1-2">${workspaces[index].Smoking}</p>
            </p>
            </div> 
            <div class="H1-4">    
            <p class="H1">Square Footage:
                <p id = seven class="H1-2">${workspaces[index].Square_Feet}</p>
            </p>
            </div>
            <div class="H1-4">
            <p class="H1">Capacity:
                <p id = eight class="H1-2">${workspaces[index].Capacity}</p>
            </p>
            </div> 
            <div class="H1-4">
            <p class="H1">Address:
                <p id = nine class="H1-2">${workspaces[index].Address}</p>
            </p>
            </div> 
            <div class="H1-4">
            <p class="H1">Neighbourhood:
                <p id = ten class="H1-2">${workspaces[index].Neighborhood}</p>
            </p>
            </div>
        </div>`;
    $("#displayDiv").append(row)
};
////////////////////////////////////////////////////////////
    // 
    // 
///////////////////////////////////////////////////////////

function DisplayAllListings(){ 
    document.getElementById("display_listings").innerHTML="<h2>All Listings: </h2>";
        for(var i = 0; i<workspaces.length;i++){

            // I made some changes here.
            document.getElementById("display_listings").innerHTML+=
            "-----------------------"+
            "<br>Listing ID: "+workspaces[i].workspace_Id+

            "<br>Price: "+workspaces[i].rent +

            "<br>Address: "+workspaces[i].address+
            "<br>Neighbourhood: "+workspaces[i].neighborhood+
            "<br>Square Feet: "+workspaces[i].square_Feet+
            "<br>Parking: "+workspaces[i].parking+

            "<br>Term: "+workspaces[i].lease_Term+
            "<br>Public Transit:"+workspaces[i].public_Transit+
            "<br>Smoking: "+workspaces[i].smoking+
            "<br>Capacity: "+workspaces[i].capacity+
            "<br><button>Select This Listing</button><br><br>-----------------------<br><br>";
            
    }
}
 ////////////////////////////////////////////////////////////
    // 
    // 
///////////////////////////////////////////////////////////
function Delist(){
    workspaces.splice(display, 1);
    workspaces.splice(display,1);
    console.log(workspaces);
    console.log(workspaces);
    displayCurrent();
    DisplayAllListings();
}

function ApplyFilters(){
    var filteredlistings=[];
    var filterTransit = document.getElementById("public_transit_filter").checked;
    var filterSmoking = document.getElementById("smoking_filter").checked;
    var filterParking = document.getElementById("parking_filter").checked;
    var filterTerm = document.getElementById("lease_terms_filter").value;
    var filterPriceMax = document.getElementById("filter_price_max").value;
    var filterPriceMin = document.getElementById("filter_price_min").value;
    var filterSquareFeetMax= document.getElementById("filter_square_feet_max").value;
    var filterSquareFeetMin= document.getElementById("filter_square_feet_min").value;
    var filterCapacityMax= document.getElementById("filter_capacity_max").value;
    var filterCapacityMin= document.getElementById("filter_capacity_min").value;
    var filterAddress= document.getElementById("filter_address").value;
    var filterNeighbourhood= document.getElementById("filter_neighbourhood").value;
    //loop through all available listings

   console.log('filterTerm', filterTerm);
   console.log(workspaces[1].Lease_Term);

    for(var i=0; i<workspaces.length; i++){

        var filterOut=false;
        //check if meets all filter criteria, then display.
        
        if(workspaces[i].public_Transit!=filterTransit){
            filterOut=true;
        }
        
        if(workspaces[i].smoking!=filterSmoking){
            filterOut=true;
        }
        if(workspaces[i].parking!=filterParking){
            filterOut=true;
        }
        if(workspaces[i].lease_Term!=filterTerm){
            filterOut=true;
        }
        if(workspaces[i].rent<filterPriceMin){
            filterOut=true;
        }
        if(workspaces[i].rent>filterPriceMax){
            filterOut=true;
        }
        if(workspaces[i].capacity<filterCapacityMin){
            filterOut=true;
        }
        if(workspaces[i].capacity>filterCapacityMax){
            filterOut=true;
        }
        if(workspaces[i].square_Feet<filterSquareFeetMin){
            filterOut=true;
        }
        if(workspaces[i].square_Feet>filterSquareFeetMax){
            filterOut=true;
        }
        if(workspaces[i].neighborhood!=filterNeighbourhood){
            filterOut=true;
        }
        
        if(!workspaces[i].Address.includes(filterAddress)){
            filterOut=true;
        }


        if(filterOut){

        }else{

            filteredlistings.push(workspaces[i]);
        }
        
    }
    
   

    console.log(filteredlistings);
    //display filtered listings
    document.getElementById("display_listings").innerHTML="";
    for(var i = 0; i<filteredlistings.length;i++){
        document.getElementById("display_listings").innerHTML+=
        "Listing ID: "+filteredlistings[i].workspace_Id+": "+
        "<br>Price: "+filteredlistings[i].rent +
        "<br>Term: "+filteredlistings[i].lease_Term+
        "<br>Public Transit:"+filteredlistings[i].public_Transit+
        "<br>Parking: "+filteredlistings[i].parking+
        "<br>Smoking: "+filteredlistings[i].smoking+
        "<br>Square Feet: "+filteredlistings[i].square_Feet+
        "<br>Capacity: "+filteredlistings[i].capacity+
        "<br>Address: "+filteredlistings[i].address+
        "<br>Neighbourhood: "+filteredlistings[i].neighborhood+"<br><br>";
    }
   // constructor(price, term, publicTransit, parking, smoking, squareFeet,  capacity, address, neighbourhood) {
}



    $.get('/get-listings', (data) => {
       workspaces = data.data
    }).then(() => {
        console.log('here')
        createListing(display);
        // DisplayAllListings();
    })
      

     ////////////////////////////////////////////////////////////
        // User Story 2 Create New Listing
    ///////////////////////////////////////////////////////////

    // Button function to create new listings.
    $("#btnCreate").click(function() {
        var newWorkspace = {
            workspace_Id: document.getElementById("txtOne").value,
            rent: document.getElementById("txtTwo").value,
            lease_Term: document.getElementById("txtThree").value,
            public_Transit: document.getElementById("txtFour").value,
            parking: document.getElementById("txtFive").value,
            smoking: document.getElementById("txtSix").value,
            square_Feet: document.getElementById("txtSeven").value,
            capacity: document.getElementById("txtEight").value,
            address: document.getElementById("txtNine").value,
            neighborhood: document.getElementById("txtTen").value
        }
        console.log("New Listing Created.")
        $.post("/owner_listings", newWorkspace);
    })

    ////////////////////////////////////////////////////////////
        // User Story 4 Edit Function 
    ///////////////////////////////////////////////////////////

    // Button function to select element to edit.
    $("#btnEdit").click(function() {
        let editWorkspace;
        console.log("Editing Listing.")
        let selectWorkspace = prompt("What do you want to edit? Options: (Workspace ID, Price, Term, Public Transport, Parking, Smoking, Square Feet, Capacity, Address, Neighborhood).");
        if(selectWorkspace == "Workspace ID", "Rent", "Lease Term", "Public Transport", "Parking", "Smoking", "Square Feet", "Capacity", "Address", "Neighborhood") {
            switch(selectWorkspace) {

            case "Workspace ID":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("one").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break

             case "Rent":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("two").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break

            case "Term":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("three").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break

            case "Public Transport":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("four").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break

            case "Parking":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("five").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break

            case "Smoking": 
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("six").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break 
                
            case "Square Feet":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("seven").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break 

            case "Capacity":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("eight").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break

            case "Address":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("nine").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break 
                
            case "Neighborhood":
                console.log(selectWorkspace + ' Selected.');
                editWorkspace = prompt("Enter desired changes.");
                document.getElementById("ten").innerHTML = editWorkspace;
                console.log('Changed to ' + editWorkspace + '.');
                break 
            }
        }
        else {
            console.log("ERROR Invalid Value");
            return 0;
        }

        
    }) 
    //////////////////////////////////////////////////
            // User Story 4 Save Edit Function 
    /////////////////////////////////////////////////
    
    // Button function to save edited listings.
    $("#btnSave").click(function() {
        var saveListing = {
            rent: document.getElementById("two").innerHTML,
            term: document.getElementById("three").innerHTML,
            transport: document.getElementById("four").innerHTML,
            parking: document.getElementById("five").innerHTML,
            smoking: document.getElementById("six").innerHTML,
            square: document.getElementById("seven").innerHTML,
            capacity: document.getElementById("eight").innerHTML,
            address: document.getElementById("nine").innerHTML,
            neighbor: document.getElementById("ten").innerHTML,    
        }
        $.post('/owner_listings', saveListing)
    })



})











