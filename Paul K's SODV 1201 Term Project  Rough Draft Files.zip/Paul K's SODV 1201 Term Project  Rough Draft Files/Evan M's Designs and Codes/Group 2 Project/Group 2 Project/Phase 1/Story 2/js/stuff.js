var dataSet = [
    ["FirstName LastName0", "Address0", "Neighborhood0", "SquareFootage0", "ParkingGarage0", "PunblicTransport0"],
    ["FirstName LastName1", "Address1", "Neighborhood1", "SquareFootage1", "ParkingGarage1", "PunblicTransport1"],
    ["FirstName LastName2", "Address2", "Neighborhood2", "SquareFootage2", "ParkingGarage2", "PunblicTransport2"],
    ["FirstName LastName3", "Address3", "Neighborhood3", "SquareFootage3", "ParkingGarage3", "PunblicTransport3"],
    ["FirstName LastName4", "Address4", "Neighborhood4", "SquareFootage4", "ParkingGarage4", "PunblicTransport4"],
    ["FirstName LastName5", "Address5", "Neighborhood5", "SquareFootage5", "ParkingGarage5", "PunblicTransport5"],
    ["FirstName LastName6", "Address6", "Neighborhood6", "SquareFootage6", "ParkingGarage6", "PunblicTransport6"],
    ["FirstName LastName7", "Address7", "Neighborhood7", "SquareFootage7", "ParkingGarage7", "PunblicTransport7"],
    ["FirstName LastName8", "Address8", "Neighborhood8", "SquareFootage8", "ParkingGarage8", "PunblicTransport8"],
    ["FirstName LastName9", "Address9", "Neighborhood9", "SquareFootage9", "ParkingGarage9", "PunblicTransport9"],
];
