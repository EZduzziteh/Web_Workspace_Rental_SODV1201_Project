function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}
function validateForm() {

    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var role = document.Form.role.value;

    var namErr= emailErr = mobileErr =roleErr=true;

    if (name=="")
    {
        printError("nameErr", "PLEASE ENTER YOUR NAME");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[a-zA-Z\s]+$/;
        if(regex.test(name)===false){
            printError("nameErr","PLEASE ENTER A VALID NAME");
            var elem=document.getElementById("name");

        }else{
            namErr=false;
            printError("nameErr","");
            var elem=document.getElementById("name");
        }
    }

    
    if (email=="")
    {
        printError("emailErr", "PLEASE ENTER YOUR EMAIL ADDRESS");
        var elem=document.getElementById("email");
        
    }
    else{
        var regex=/^S+@\S+\.\S+$/;
        if(regex.test(email)===false){
            printError("emailErr","PLEASE ENTER A VALId EMAIL ADDRESS");
            var elem=document.getElementById("email");

        }else{
            namErr=false;
            printError("emailErr","");
            var elem=document.getElementById("email");
        }
    }




    if (mobile-number=="")
    {
        printError("mobileErr", "PLEASE ENTER YOUR MOBILE NUMBER");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[1-9]\d{9}$/;
        if(regex.test(mobile)=== false){
            printError("mobileErr","PLEASE ENTER A VALID 10 DIGIT MOBILE NUMBER");
            var elem=document.getElementById("mobile");

        }else{
            mobileErr=false;
            printError("mobileErr","");
            var elem=document.getElementById("mobile");
        }
    }

    
    if (role="")
    {
        printError("roleErr", "PLEASE ENTER YOUR ROLE");
        var elem=document.getElementById("ole");
        
    }else{
        printError("roleErr","");
            roleErr=false;
            var elem=document.getElementById("role");
        }
    

        if ((nameErr|| emailErr||mobileErr||roleErr)== true){
            return false;
        }

};