
/* SODV 1201 Introduction to Web Programming 
SODV 1201 Term Project- Co-Worker Office Space 
 Program designed and coded by: SODV 1201 Group 2: Sasha Greene,  Gurleen Kaur, Paul K Kho, Evan Maclean
 Instructor:                   Dima Marachi
 Due       :     Phase 1   : June 2 2022
                 Phase 2   : June 24 2022 
*/

let display = 0;

const listing = dataSet.map(listing => {
    return {
        name: listing[0],
        address: listing[1],
        neighborhood: listing[2],
        square_feet: listing[3],
        parking: listing[4],
        public_transport: listing[5]
    }
});
     ////////////////////////////////////////////////////////////
        // User Story 2 Display Listings
    ///////////////////////////////////////////////////////////
function displayNext() {
    if(display > listing.length -2) return 
    display++
    createListing(display)
    console.log(display)
};

function displayPrev() {
    if(display < 1) return 
    display--
    createListing(display)
    console.log(display)
};

function createListing(index) { 

    $("#displayDiv").empty();
    let row = `
        <div class="H1-1">
            <div class="H1-4">
                <p class="H1">Listing:
                    <p id = one class="H1-2">${listing[index].name}</p>
                </p>
            </div>
            <div class="H1-4">
                <p class="H1">Address:
                    <p id = two class="H1-2">${listing[index].address}</p>
                </p>
            </div>
            <div class="H1-4">
                <p class="H1">Location:
                    <p id = three class="H1-2">${listing[index].neighborhood}</p>
                </p>
            </div>
            <div class="H1-4">    
                <p class="H1">Square Footage:
                    <p id = four class="H1-2">${listing[index].square_feet}</p>
                </p>
            </div>
            <div class="H1-4">
                <p class="H1">Parking Garage:
                    <p id = five class="H1-2">${listing[index].parking}</p>
                </p>
            </div>
            <div class="H1-4">
                <p class="H1">Public Transport:
                    <p id = six class="H1-2">${listing[index].public_transport}</p>
                </p>
            </div>    
        </div>`;
    $("#displayDiv").append(row)
};
//
$(document).ready(function() {
    createListing(display);
     ////////////////////////////////////////////////////////////
        // User Story 2 Create New Listing
    ///////////////////////////////////////////////////////////

    $("#btnCreate").click(function() {
        var newListing = {
            name: document.getElementById("txtOne").value,
            address: document.getElementById("txtTwo").value,
            neighborhood: document.getElementById("txtThree").value,
            square_feet: document.getElementById("txtFour").value,
            parking: document.getElementById("txtFive").value,
            public_transport: document.getElementById("txtSix").value
        }
        listing.push(newListing)
    })

    // function createListing() {
    //     let Name = document.getElementById("txtOne").value;
    //     let Address = document.getElementById("txtTwo").value;
    //     let Neighborhood = document.getElementById("txtThree").value;
    //     let Square_Foot = document.getElementById("txtFour").value;
    //     let Parking = document.getElementById("txtFive").value;
    //     let Public_Transport = document.getElementById("txtSix").value;
    //     let userInput = [[listing.name = Name]];
    //     console.log(userInput);
    //     listing.push(userInput);
    // }

    ////////////////////////////////////////////////////////////
        // User Story 4 Edit Function
    ///////////////////////////////////////////////////////////
    $("#btnEdit").click(function() {
        let editListing;
        let selectListing = prompt("What do you want to edit? Options: (Name, Address, Neighborhood, Square Feet, Parking, Public Transport).");
        if(selectListing == "Name" || "Address" || "Neighborhood" || "Square Feet" || "Parking" || "Public Transport") {
            switch(selectListing) {

            case "Name":
                editListing = prompt("Enter desired changes.");
                document.getElementById("one").innerHTML = editListing;
                break

             case "Address":
                editListing = prompt("Enter desired changes.");
                document.getElementById("two").innerHTML = editListing;
                break

            case "Neighborhood":
                editListing = prompt("Enter desired changes.");
                document.getElementById("three").innerHTML = editListing;
                break

            case "Square Feet":
                editListing = prompt("Enter desired changes.");
                document.getElementById("four").innerHTML = editListing;
                break

            case "Parking":
                editListing = prompt("Enter desired changes.");
                document.getElementById("five").innerHTML = editListing;
                break

            case "Public Transport":
                editListing = prompt("Enter desired changes.");
                document.getElementById("six").innerHTML = editListing;
                break            
            }
        }
        else {
            let errorMsg = prompt("Invalid Value. Would you Like to retry?")
            return 0;
        }
    }) 
    //////////////////////////////////////////////////
            // User Story 4 Save Edit Function
    /////////////////////////////////////////////////

    $("#btnSave").click(function() {
        let saveName = document.getElementById("one").innerHTML;
        let saveAddress = document.getElementById("two").innerHTML;
        let saveNeighbor = document.getElementById("three").innerHTML;
        let saveSquare = document.getElementById("four").innerHTML;
        let saveParking = document.getElementById("five").innerHTML;
        let saveTransporte = document.getElementById("six").innerHTML;
        listing[display].name = saveName;
        listing[display].address = saveAddress;
        listing[display].neighborhood = saveNeighbor;
        listing[display].square_feet = saveSquare;
        listing[display].parking = saveParking;
        listing[display].public_transport = saveTransporte;
        console.log("Listing Edited");
    })
})


let text;

$(document).ready(function() {
    $("btnEdit").click(function() {
        switch(editColumn) {
            case "Name":
                editRow;
                break;

            case "Address":
                editRow
        }
    })



    $("#btnEdit").click(function() {
        let editListing;
        let selectListing = prompt("What do you want to edit? Options: (Name, Address, Neighborhood, Square Feet, Parking, Public Transport).");
        if(selectListing == "Name" || "Address" || "Neighborhood" || "Square Feet" || "Parking" || "Public Transport") {
            switch(selectListing) {

                case "Name":
                    editListing = prompt("Enter desired changes.");
                    document.getElementById("display0").innerHTML = editListing;
                    break

                case "Address":
                    editListing = prompt("Enter desired changes.");
                    document.getElementById("display1").innerHTML = editListing;
                    break

                case "Neighborhood":
                    editListing = prompt("Enter desired changes.");
                    document.getElementById("display2").innerHTML = editListing;
                    break

                case "Square Feet":
                    editListing = prompt("Enter desired changes.");
                    document.getElementById("display3").innerHTML = editListing;
                    break

                case "Parking":
                    editListing = prompt("Enter desired changes.");
                    document.getElementById("display4").innerHTML = editListing;
                    break

                case "Public Transport":
                    editListing = prompt("Enter desired changes.");
                    document.getElementById("display5").innerHTML = editListing;
                    break            
                }
            }
            else {
                let errorMsg = prompt("Invalid Value. Would you Like to retry?")
                return 0;
            }

    }) 

    $("#btnSave").click(function() {
        let saveValue = {
            name: saveValue[0],
            address: saveValue[1],
            neighborhood: saveValue[2],
            square_foot: saveValue[3],
            parking: saveValue[4],
            public_transport: saveValue[5],
        }
        document.getElementById("display0").value = saveName; 
        document.getElementById("display0").value = saveAddress;
        document.getElementById("display0").value = saveNeighbor;
        parseInt(document.getElementById("display0").value) = saveSquare;
        document.getElementById("display0").value = saveParking;
        document.getElementById("display0").value = saveTransporte;
        if(saveValue.name == null || saveValue.address == null || saveValue.neighborhood == null || saveValue.square_foot == null || saveValue.parking == null || saveValue.public_transport == null ) {
            saveName = saveValue.name;
            saveAddress = saveValue.address;
            saveNeighbor = saveValue.neighborhood;
            saveSquare = saveValue.square_foot;
            saveParking = saveValue.parking;
            saveTransporte = saveValue.public_transport;
            console.log(saveValue[0])
            let saved = prompt("Listing Edit Saved");
            return saveValue;
        }
        else {
            let error = prompt("Listing Not Saved Missing Requirment.")
            return 0;
        }
    })
})

