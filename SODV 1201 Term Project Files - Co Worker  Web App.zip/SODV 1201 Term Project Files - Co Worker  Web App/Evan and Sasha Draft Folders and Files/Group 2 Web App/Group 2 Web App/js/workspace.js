// SODV 1201 Term Project 
// Javascript, Node, API and REST API 
// Sasha and Evan

let display = 0;
// Object we are using for all listings.
class Listing1 {
    constructor(listingID, price, term, publicTransit, parking, smoking, squareFeet,  capacity, address, neighbourhood) {
        this.listingID=listingID;
        this.price = price;
        this.term=term;
        this.publicTransit=publicTransit;
        this.parking=parking;
        this.smoking=smoking;
        this.squareFeet=squareFeet;
        this.capacity=capacity;
        this.address=address;
        this.neighbourhood=neighbourhood;

    }
}

let listing1 = new Listing1("001", 200, "Daily", true, true, false, 200, 1, "1221 Queen Avenue", "Thornhill" );
let listing2 = new Listing1("002", 1200, "Weekly", false, true, false, 600, 4 , "1234 long Street", "Meadowbrook");
let listing3 = new Listing1("003", 2000, "Monthly", false, false, false, 1200, 8 , "342 Aron Way", "Big Hills");
let listing4 = new Listing1("004", 500, "Weekly", true, true, true, 1000, 6 , "1336 King Street", "Remo");
let listing5 = new Listing1("005", 875, "Weekly", true, false, true, 350, 1 , "2201 Brightwell Road", "Central");
let listing6 = new Listing1("006", 250, "Daily", true, true, false, 356, 3, "1216 Queen Avenue", "Thornhill" );
let listing7 = new Listing1("007", 2200, "Monthly", false, false, false, 900, 6 , "343 Aron Way", "Big Hills");
let listing8 = new Listing1("008", 675, "Daily", true, true, false, 600, 6, "1000 Queen Avenue", "Thornhill" );

var listings  = [listing1, listing2, listing3, listing4, listing5, listing6, listing7, listing8];

function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}
function validateForm() {

    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var role = document.Form.role.value;

    var namErr= emailErr = mobileErr =roleErr=true;

    if (name=="")
    {
        printError("nameErr", "PLEASE ENTER YOUR NAME");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[a-zA-Z\s]+$/;
        if(regex.test(name)===false){
            printError("nameErr","PLEASE ENTER A VALID NAME");
            var elem=document.getElementById("name");

        }else{
            namErr=false;
            printError("nameErr","");
            var elem=document.getElementById("name");
        }
    }

    
    if (email=="")
    {
        printError("emailErr", "PLEASE ENTER YOUR EMAIL ADDRESS");
        var elem=document.getElementById("email");
        
    }
    else{
        var regex=/^S+@\S+\.\S+$/;
        if(regex.test(email)===false){
            printError("emailErr","PLEASE ENTER A VALId EMAIL ADDRESS");
            var elem=document.getElementById("email");

        }else{
            namErr=false;
            printError("emailErr","");
            var elem=document.getElementById("email");
        }
    }




    if (mobile-number=="")
    {
        printError("mobileErr", "PLEASE ENTER YOUR MOBILE NUMBER");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[1-9]\d{9}$/;
        if(regex.test(mobile)=== false){
            printError("mobileErr","PLEASE ENTER A VALID 10 DIGIT MOBILE NUMBER");
            var elem=document.getElementById("mobile");

        }else{
            mobileErr=false;
            printError("mobileErr","");
            var elem=document.getElementById("mobile");
        }
    }

    
    if (role="")
    {
        printError("roleErr", "PLEASE ENTER YOUR ROLE");
        var elem=document.getElementById("ole");
        
    }else{
        printError("roleErr","");
            roleErr=false;
            var elem=document.getElementById("role");
        }
    

        if ((nameErr|| emailErr||mobileErr||roleErr)== true){
            return false;
        }

};
 ////////////////////////////////////////////////////////////
    // User Story 2 Display Listings
///////////////////////////////////////////////////////////

// Button display next listing.
function displayNext() {
    if(display > listings.length -2) return 
    display++
    createListing(display)
    console.log(display)
};
function displaySpecific(index) {
    if(display > listings.length -2) return 
    
    createListing(index)
    console.log(index)
};
// Display Current Value
function displayCurrent(){
    if(display > listings.length -2) return 
    createListing(display)
    console.log(display)
}
// Button display prev listing.
function displayPrev() {
    if(display < 1) return 
    display--
    createListing(display)
    console.log(display)
};

 ////////////////////////////////////////////////////////////
    // User Story 2 Display Listing 
///////////////////////////////////////////////////////////

// Ablility to edit displayed listings.
function createListing(index) { 

    $("#displayDiv").empty();
    let row = `
        <div class="H1-1">
            <div class="H1-4">
                <p class="H1">Listing ID:
                    <p id = one class="H1-2">${listings[index].listingID}</p>
                </p>
            </div>
            <div class="H1-4">
            <p class="H1">Price:
                <p id = two class="H1-2">${listings[index].price}</p>
            </p>
            </div>
            <div class="H1-4">
            <p class="H1">Term:
                <p id = three class="H1-2">${listings[index].term}</p>
            </p>
            </div>
            <div class="H1-4">
                <p class="H1">Public Transport:
                    <p id = four class="H1-2">${listings[index].publicTransit}</p>
                </p>
            </div> 
            <div class="H1-4">
            <p class="H1">Parking:
                <p id = five class="H1-2">${listings[index].parking}</p>
            </p>
            </div>
            <div class="H1-4">    
            <p class="H1">Smoking:
                <p id = six class="H1-2">${listings[index].smoking}</p>
            </p>
            </div> 
            <div class="H1-4">    
            <p class="H1">Square Footage:
                <p id = seven class="H1-2">${listings[index].squareFeet}</p>
            </p>
            </div>
            <div class="H1-4">
            <p class="H1">Capacity:
                <p id = eight class="H1-2">${listings[index].capacity}</p>
            </p>
            </div> 
            <div class="H1-4">
            <p class="H1">Address:
                <p id = nine class="H1-2">${listings[index].address}</p>
            </p>
            </div> 
            <div class="H1-4">
            <p class="H1">Neighbourhood:
                <p id = ten class="H1-2">${listings[index].neighbourhood}</p>
            </p>
            </div>
        </div>`;
    $("#displayDiv").append(row)
    DisplayAllListings();
};
////////////////////////////////////////////////////////////
    // 
    // 
///////////////////////////////////////////////////////////

function DisplayAllListings(){

    document.getElementById("display_listings").innerHTML="<h2>All Listings: </h2>";
        for(var i = 0; i<listings.length;i++){

            // I made some changes here.
            document.getElementById("display_listings").innerHTML+=
            "-----------------------"+
            "<br>Listing ID: "+listings[i].listingID+

            "<br>Price: "+listings[i].price +

            "<br>Address: "+listings[i].address+
            "<br>Neighbourhood: "+listings[i].neighbourhood+
            "<br>Square Feet: "+listings[i].squareFeet+
            "<br>Parking: "+listings[i].parking+

            "<br>Term: "+listings[i].term+
            "<br>Public Transit:"+listings[i].publicTransit+
            "<br>Smoking: "+listings[i].smoking+
            "<br>Capacity: "+listings[i].capacity+
            "<br><button>Select This Listing</button><br><br>-----------------------<br><br>";
            
    }
}
 ////////////////////////////////////////////////////////////
    // 
    // 
///////////////////////////////////////////////////////////
function Delist(){
   
    listings.splice(display, 1);
    listings.splice(display,1);
    console.log(listings);
    console.log(listings);
    displayCurrent();
    DisplayAllListings();
}

function ApplyFilters(){
    var filteredlistings=[];
    var filterTransit = document.getElementById("public_transit_filter").checked;
    var filterSmoking = document.getElementById("smoking_filter").checked;
    var filterParking = document.getElementById("parking_filter").checked;
    var filterTerm = document.getElementById("lease_terms_filter").value;
    var filterPriceMax = document.getElementById("filter_price_max").value;
    var filterPriceMin = document.getElementById("filter_price_min").value;
    var filterSquareFeetMax= document.getElementById("filter_square_feet_max").value;
    var filterSquareFeetMin= document.getElementById("filter_square_feet_min").value;
    var filterCapacityMax= document.getElementById("filter_capacity_max").value;
    var filterCapacityMin= document.getElementById("filter_capacity_min").value;
    var filterAddress= document.getElementById("filter_address").value;
    var filterNeighbourhood= document.getElementById("filter_neighbourhood").value;
    //loop through all available listings

   console.log(filterTerm);
   console.log(listings[1].term);

    for(var i=0; i<listings.length; i++){

        var filterOut=false;
        //check if meets all filter criteria, then display.
        
        if(listings[i].publicTransit!=filterTransit){
            filterOut=true;
        }
        
        if(listings[i].smoking!=filterSmoking){
            filterOut=true;
        }
        if(listings[i].parking!=filterParking){
            filterOut=true;
        }
        if(listings[i].term!=filterTerm){
            filterOut=true;
        }
        if(listings[i].price<filterPriceMin){
            filterOut=true;
        }
        if(listings[i].price>filterPriceMax){
            filterOut=true;
        }
        if(listings[i].capacity<filterCapacityMin){
            filterOut=true;
        }
        if(listings[i].capacity>filterCapacityMax){
            filterOut=true;
        }
        if(listings[i].squareFeet<filterSquareFeetMin){
            filterOut=true;
        }
        if(listings[i].squareFeet>filterSquareFeetMax){
            filterOut=true;
        }
        if(listings[i].neighbourhood!=filterNeighbourhood){
            filterOut=true;
        }
        
        if(!listings[i].address.includes(filterAddress)){
            filterOut=true;
        }


        if(filterOut){

        }else{

            filteredlistings.push(listings[i]);
        }
        
    }
    
   

    console.log(filteredlistings);
    //display filtered listings
    document.getElementById("display_listings").innerHTML="";
    for(var i = 0; i<filteredlistings.length;i++){
        document.getElementById("display_listings").innerHTML+=
        "Listing ID: "+filteredlistings[i].listingID+": "+
        "<br>Price: "+filteredlistings[i].price +
        "<br>Term: "+filteredlistings[i].term+
        "<br>Public Transit:"+filteredlistings[i].publicTransit+
        "<br>Parking: "+filteredlistings[i].parking+
        "<br>Smoking: "+filteredlistings[i].smoking+
        "<br>Square Feet: "+filteredlistings[i].squareFeet+
        "<br>Capacity: "+filteredlistings[i].capacity+
        "<br>Address: "+filteredlistings[i].address+
        "<br>Neighbourhood: "+filteredlistings[i].neighbourhood+"<br><br>";
    }
   // constructor(price, term, publicTransit, parking, smoking, squareFeet,  capacity, address, neighbourhood) {
}


// Start of $(document)
$(document).ready(function() {

 
    createListing(display);
    DisplayAllListings();
        
     ////////////////////////////////////////////////////////////
        // User Story 2 Create New Listing
    ///////////////////////////////////////////////////////////

    // Button function to create new listings.
    $("#btnCreate").click(function() {
        var newListing = {
            listingID: document.getElementById("txtOne").value,
            price: document.getElementById("txtTwo").value,
            term: document.getElementById("txtThree").value,
            publicTransit: document.getElementById("txtFour").value,
            parking: document.getElementById("txtFive").value,
            smoking: document.getElementById("txtSix").value,
            squareFeet: document.getElementById("txtSeven").value,
            capacity: document.getElementById("txtEight").value,
            address: document.getElementById("txtNine").value,
            neighbourhood: document.getElementById("txtTen").value
        }
        listings.push(newListing)
        console.log("New Listing Created.")
      
      
    })

    ////////////////////////////////////////////////////////////
        // User Story 4 Edit Function 
    ///////////////////////////////////////////////////////////

    // Button function to select element to edit.
    $("#btnEdit").click(function() {
        let editListing;
        console.log("Editing Listing.")
        let selectListing = prompt("What do you want to edit? Options: (listing ID, Price, Term, Public Transport, Parking, Smoking, Square Feet, Capacity, Address, Neighbourhood).");
        if(selectListing == "listing ID", "Price", "Term", "Public Transport", "Parking", "Smoking", "Square Feet", "Capacity", "Address", "Neighbourhood") {
            switch(selectListing) {

            case "Listing ID":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("one").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break

             case "Price":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("two").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break

            case "Term":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("three").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break

            case "Public Transport":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("four").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break

            case "Parking":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("five").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break

            case "Smoking":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("six").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break 
                
            case "Square Feet":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("seven").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break 

            case "Capacity":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("eight").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break

            case "Address":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("nine").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break 
                
            case "Neighbourhood":
                console.log(selectListing + ' Selected.');
                editListing = prompt("Enter desired changes.");
                document.getElementById("ten").innerHTML = editListing;
                console.log('Changed to ' + editListing + '.');
                break 
            }
        }
        else {
            console.log("ERROR Invalid Value");
            return 0;
        }

        
    }) 
    //////////////////////////////////////////////////
            // User Story 4 Save Edit Function
    /////////////////////////////////////////////////

    // Button function to save edited listings.
    $("#btnSave").click(function() {
        let savelistingID = document.getElementById("one").innerHTML;
        let savePrice = document.getElementById("two").innerHTML;
        let saveTerm = document.getElementById("three").innerHTML;
        let saveTransport = document.getElementById("four").innerHTML;
        let saveParking = document.getElementById("five").innerHTML;
        let saveSmoking = document.getElementById("six").innerHTML;
        let saveSquare = document.getElementById("seven").innerHTML;
        let saveCapacity = document.getElementById("eight").innerHTML;
        let saveAddress = document.getElementById("nine").innerHTML;
        let saveNeighbour = document.getElementById("ten").innerHTML;
        listings[display].listingID = savelistingID;
        listings[display].price = savePrice;
        listings[display].term = saveTerm;
        listings[display].publicTransit = saveTransport;
        listings[display].parking = saveParking;
        listings[display].smoking = saveSmoking;
        listings[display].squareFeet = saveSquare;
        listings[display].capacity = saveCapacity;
        listings[display].address = saveAddress;
        listings[display].neighbourhood = saveNeighbour;
        console.log("Listing Edited");
    })
})













