/* SODV 1201 Introduction to Web Programming 
SODV 1201 Term Project- Co-Worker Work Spaces and Properties 
 Program designed and coded by: SODV 1201 Group 2: Sasha Greene,  Gurleen Kaur, Paul K Kho, Evan Maclean
 Instructor:                   Dima Marachi
 Due       :     Phase 1   : June 2 2022
                 Phase 2   : June 24 2022 
*/

// User Stories 1 and 3 
// Landing Page (Home Page )

var RegName1 = "CoWorker";
var RegName2 = "Owner CoWorker";
var password = "Pass2022";

function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}
function validateForm() {

    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var role = document.Form.role.value;

    var namErr= emailErr = mobileErr =roleErr=true;

    if (name=="")
    {
        printError("nameErr", "PLEASE ENTER YOUR NAME");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[a-zA-Z\s]+$/;
        if(regex.test(name)===false){
            printError("nameErr","PLEASE ENTER A VALID NAME");
            var elem=document.getElementById("name");

        }else{
            namErr=false;
            printError("nameErr","");
            var elem=document.getElementById("name");
        }
    }

    
    if (email=="")
    {
        printError("emailErr", "PLEASE ENTER YOUR EMAIL ADDRESS");
        var elem=document.getElementById("email");
        
    }
    else{
        var regex=/^S+@\S+\.\S+$/;
        if(regex.test(email)===false){
            printError("emailErr","PLEASE ENTER A VALId EMAIL ADDRESS");
            var elem=document.getElementById("email");

        }else{
            namErr=false;
            printError("emailErr","");
            var elem=document.getElementById("email");
        }
    }

    if (mobile-number=="")
    {
        printError("mobileErr", "PLEASE ENTER YOUR MOBILE NUMBER");
        var elem=document.getElementById("name");
        
    }
    else{
        var regex=/^[1-9]\d{9}$/;
        if(regex.test(mobile)=== false){
            printError("mobileErr","PLEASE ENTER A VALID 10 DIGIT MOBILE NUMBER");
            var elem=document.getElementById("mobile");

        }else{
            mobileErr=false;
            printError("mobileErr","");
            var elem=document.getElementById("mobile");
        }
    }

    
    if (role="")
    {
        printError("roleErr", "PLEASE ENTER YOUR ROLE");
        var elem=document.getElementById("ole");
        
    }else{
        printError("roleErr","");
            roleErr=false;
            var elem=document.getElementById("role");
        }
    if ((nameErr|| emailErr||mobileErr||roleErr)== true){
            return false;
        }
    if (name==RegName1) {
        role = "coworker";
    }
    if (name==RegName2) {
        role = "OwnerCoWorker";
    }   
    document.getElementById("welcome").innerHTML = ("Welcome " + elem);
};


// User Stories 2 and 4


// let display = 0;

// const listing = dataSet.map(listing => {
//     return {
//         name: listing[0],
//         address: listing[1],
//         neighborhood: listing[2],
//         square_feet: listing[3],
//         parking: listing[4],
//         public_transport: listing[5]
//     }
// });
//      ////////////////////////////////////////////////////////////
//         // User Story 2 Display Listings
//     ///////////////////////////////////////////////////////////
// function displayNext() {
//     if(display > listing.length -2) return 
//     display++
//     createListing(display)
//     console.log(display)
// };

// function displayPrev() {
//     if(display < 1) return 
//     display--
//     createListing(display)
//     console.log(display)
// };

// function createListing(index) { 

//     $("#displayDiv").empty();
//     let row = `
//         <div class="H1-1">
//             <div class="H1-4">
//                 <p class="H1">Listing:
//                     <p id = one class="H1-2">${listing[index].name}</p>
//                 </p>
//             </div>
//             <div class="H1-4">
//                 <p class="H1">Address:
//                     <p id = two class="H1-2">${listing[index].address}</p>
//                 </p>
//             </div>
//             <div class="H1-4">
//                 <p class="H1">Location:
//                     <p id = three class="H1-2">${listing[index].neighborhood}</p>
//                 </p>
//             </div>
//             <div class="H1-4">    
//                 <p class="H1">Square Footage:
//                     <p id = four class="H1-2">${listing[index].square_feet}</p>
//                 </p>
//             </div>
//             <div class="H1-4">
//                 <p class="H1">Parking Garage:
//                     <p id = five class="H1-2">${listing[index].parking}</p>
//                 </p>
//             </div>
//             <div class="H1-4">
//                 <p class="H1">Public Transport:
//                     <p id = six class="H1-2">${listing[index].public_transport}</p>
//                 </p>
//             </div>    
//         </div>`;
//     $("#displayDiv").append(row)
// };
// //
// $(document).ready(function() {
//     createListing(display);
//      ////////////////////////////////////////////////////////////
//         // User Story 2 Create New Listing
//     ///////////////////////////////////////////////////////////

//     $("#btnCreate").click(function() {
//         var newListing = {
//             name: document.getElementById("txtOne").value,
//             address: document.getElementById("txtTwo").value,
//             neighborhood: document.getElementById("txtThree").value,
//             square_feet: document.getElementById("txtFour").value,
//             parking: document.getElementById("txtFive").value,
//             public_transport: document.getElementById("txtSix").value
//         }
//         listing.push(newListing)
//     })

//     // function createListing() {
//     //     let Name = document.getElementById("txtOne").value;
//     //     let Address = document.getElementById("txtTwo").value;
//     //     let Neighborhood = document.getElementById("txtThree").value;
//     //     let Square_Foot = document.getElementById("txtFour").value;
//     //     let Parking = document.getElementById("txtFive").value;
//     //     let Public_Transport = document.getElementById("txtSix").value;
//     //     let userInput = [[listing.name = Name]];
//     //     console.log(userInput);
//     //     listing.push(userInput);
//     // }

//     ////////////////////////////////////////////////////////////
//         // User Story 4 Edit Function
//     ///////////////////////////////////////////////////////////
//     $("#btnEdit").click(function() {
//         let editListing;
//         let selectListing = prompt("What do you want to edit? Options: (Name, Address, Neighborhood, Square Feet, Parking, Public Transport).");
//         if(selectListing == "Name" || "Address" || "Neighborhood" || "Square Feet" || "Parking" || "Public Transport") {
//             switch(selectListing) {

//             case "Name":
//                 editListing = prompt("Enter desired changes.");
//                 document.getElementById("one").innerHTML = editListing;
//                 break

//              case "Address":
//                 editListing = prompt("Enter desired changes.");
//                 document.getElementById("two").innerHTML = editListing;
//                 break

//             case "Neighborhood":
//                 editListing = prompt("Enter desired changes.");
//                 document.getElementById("three").innerHTML = editListing;
//                 break

//             case "Square Feet":
//                 editListing = prompt("Enter desired changes.");
//                 document.getElementById("four").innerHTML = editListing;
//                 break

//             case "Parking":
//                 editListing = prompt("Enter desired changes.");
//                 document.getElementById("five").innerHTML = editListing;
//                 break

//             case "Public Transport":
//                 editListing = prompt("Enter desired changes.");
//                 document.getElementById("six").innerHTML = editListing;
//                 break            
//             }
//         }
//         else {
//             let errorMsg = prompt("Invalid Value. Would you Like to retry?")
//             return 0;
//         }
//     }) 
//     //////////////////////////////////////////////////
//             // User Story 4 Save Edit Function
//     /////////////////////////////////////////////////

//     $("#btnSave").click(function() {
//         let saveName = document.getElementById("one").innerHTML;
//         let saveAddress = document.getElementById("two").innerHTML;
//         let saveNeighbor = document.getElementById("three").innerHTML;
//         let saveSquare = document.getElementById("four").innerHTML;
//         let saveParking = document.getElementById("five").innerHTML;
//         let saveTransporte = document.getElementById("six").innerHTML;
//         listing[display].name = saveName;
//         listing[display].address = saveAddress;
//         listing[display].neighborhood = saveNeighbor;
//         listing[display].square_feet = saveSquare;
//         listing[display].parking = saveParking;
//         listing[display].public_transport = saveTransporte;
//         console.log("Listing Edited");
//     })
// })


// let text;

// $(document).ready(function() {
//     $("btnEdit").click(function() {
//         switch(editColumn) {
//             case "Name":
//                 editRow;
//                 break;

//             case "Address":
//                 editRow
//         }
//     })



//     $("#btnEdit").click(function() {
//         let editListing;
//         let selectListing = prompt("What do you want to edit? Options: (Name, Address, Neighborhood, Square Feet, Parking, Public Transport).");
//         if(selectListing == "Name" || "Address" || "Neighborhood" || "Square Feet" || "Parking" || "Public Transport") {
//             switch(selectListing) {

//                 case "Name":
//                     editListing = prompt("Enter desired changes.");
//                     document.getElementById("display0").innerHTML = editListing;
//                     break

//                 case "Address":
//                     editListing = prompt("Enter desired changes.");
//                     document.getElementById("display1").innerHTML = editListing;
//                     break

//                 case "Neighborhood":
//                     editListing = prompt("Enter desired changes.");
//                     document.getElementById("display2").innerHTML = editListing;
//                     break

//                 case "Square Feet":
//                     editListing = prompt("Enter desired changes.");
//                     document.getElementById("display3").innerHTML = editListing;
//                     break

//                 case "Parking":
//                     editListing = prompt("Enter desired changes.");
//                     document.getElementById("display4").innerHTML = editListing;
//                     break

//                 case "Public Transport":
//                     editListing = prompt("Enter desired changes.");
//                     document.getElementById("display5").innerHTML = editListing;
//                     break            
//                 }
//             }
//             else {
//                 let errorMsg = prompt("Invalid Value. Would you Like to retry?")
//                 return 0;
//             }

//     }) 

//     $("#btnSave").click(function() {
//         let saveValue = {
//             name: saveValue[0],
//             address: saveValue[1],
//             neighborhood: saveValue[2],
//             square_foot: saveValue[3],
//             parking: saveValue[4],
//             public_transport: saveValue[5],
//         }
//         document.getElementById("display0").value = saveName; 
//         document.getElementById("display0").value = saveAddress;
//         document.getElementById("display0").value = saveNeighbor;
//         parseInt(document.getElementById("display0").value) = saveSquare;
//         document.getElementById("display0").value = saveParking;
//         document.getElementById("display0").value = saveTransporte;
//         if(saveValue.name == null || saveValue.address == null || saveValue.neighborhood == null || saveValue.square_foot == null || saveValue.parking == null || saveValue.public_transport == null ) {
//             saveName = saveValue.name;
//             saveAddress = saveValue.address;
//             saveNeighbor = saveValue.neighborhood;
//             saveSquare = saveValue.square_foot;
//             saveParking = saveValue.parking;
//             saveTransporte = saveValue.public_transport;
//             console.log(saveValue[0])
//             let saved = prompt("Listing Edit Saved");
//             return saveValue;
//         }
//         else {
//             let error = prompt("Listing Not Saved Missing Requirment.")
//             return 0;
//         }
//     })
// })


// class Listing {
//     constructor(listingID, price, term, publicTransit, parking, smoking, squareFeet,  capacity, address, neighbourhood) {
//         this.listingID=listingID;
//         this.price = price;
//         this.term=term;
//         this.publicTransit=publicTransit;
//         this.parking=parking;
//         this.smoking=smoking;
//         this.squareFeet=squareFeet;
//         this.capacity=capacity;
//         this.address=address;
//         this.neighbourhood=neighbourhood;

//     }
// }

// let listing1 = new Listing("001", 200, "Daily", true, true, false, 200, 1, "1221 Queen Avenue", "Thornhill" );
// let listing2 = new Listing("002", 1200, "Weekly", false, true, false, 600, 4 , "1234 long Street", "Meadowbrook");
// let listing3 = new Listing("003", 2000, "Monthly", false, false, false, 1200, 8 , "342 Aron Way", "Big Hills");
// let listing4 = new Listing("004", 500, "Weekly", true, true, true, 1000, 6 , "1336 King Street", "Remo");
// let listing5 = new Listing("005", 875, "Weekly", true, false, true, 350, 1 , "2201 Brightwell Road", "Central");
// let listing6 = new Listing("006", 250, "Daily", true, true, false, 356, 3, "1216 Queen Avenue", "Thornhill" );
// let listing7 = new Listing("007", 2200, "Monthly", false, false, false, 900, 6 , "343 Aron Way", "Big Hills");
// let listing8 = new Listing("008", 675, "Daily", true, true, false, 600, 6, "1000 Queen Avenue", "Thornhill" );

// var listings  = [listing1, listing2, listing3, listing4, listing5, listing6, listing7, listing8];

// function DisplayAllListings(){
//     document.getElementById("display_listings").innerHTML="";
//     for(var i = 0; i<listings.length;i++){
//         document.getElementById("display_listings").innerHTML+=
//         "Listing ID: "+listings[i].listingID+": "+
//         "<br>Price: "+listings[i].price +
//         "<br>Term: "+listings[i].term+
//         "<br>Public Transit:"+listings[i].publicTransit+
//         "<br>Parking: "+listings[i].parking+
//         "<br>Smoking: "+listings[i].smoking+
//         "<br>Square Feet: "+listings[i].squareFeet+
//         "<br>Capacity: "+listings[i].capacity+
//         "<br>Address: "+listings[i].address+
//         "<br>Neighbourhood: "+listings[i].neighbourhood+"<br><br>";
//     }
// }


// function Delist(){
//     var listingID = document.getElementById("delist_input_id");
//     var index = listings.indexOf(listingID);
//     listings.splice(index, 1);
//     console.log(listings);
//     DisplayAllListings();
// }
// function ApplyFilters(){
//     var filteredlistings=[];
//     var filterTransit = document.getElementById("public_transit_filter").checked;
//     var filterSmoking = document.getElementById("smoking_filter").checked;
//     var filterParking = document.getElementById("parking_filter").checked;
//     var filterTerm = document.getElementById("lease_terms_filter").value;
//     var filterPriceMax = document.getElementById("filter_price_max").value;
//     var filterPriceMin = document.getElementById("filter_price_min").value;
//     var filterSquareFeetMax= document.getElementById("filter_square_feet_max").value;
//     var filterSquareFeetMin= document.getElementById("filter_square_feet_min").value;
//     var filterCapacityMax= document.getElementById("filter_capacity_max").value;
//     var filterCapacityMin= document.getElementById("filter_capacity_min").value;
//     var filterAddress= document.getElementById("filter_address").value;
//     var filterNeighbourhood= document.getElementById("filter_neighbourhood").value;
//     //loop through all available listings

//    console.log(filterTerm);
//    console.log(listings[1].term);

//     for(var i=0; i<listings.length; i++){

//         var filterOut=false;
//         //check if meets all filter criteria, then display.
        
//         if(listings[i].publicTransit!=filterTransit){
//             filterOut=true;
//         }
        
//         if(listings[i].smoking!=filterSmoking){
//             filterOut=true;
//         }
//         if(listings[i].parking!=filterParking){
//             filterOut=true;
//         }
//         if(listings[i].term!=filterTerm){
//             filterOut=true;
//         }
//         if(listings[i].price<filterPriceMin){
//             filterOut=true;
//         }
//         if(listings[i].price>filterPriceMax){
//             filterOut=true;
//         }
//         if(listings[i].capacity<filterCapacityMin){
//             filterOut=true;
//         }
//         if(listings[i].capacity>filterCapacityMax){
//             filterOut=true;
//         }
//         if(listings[i].squareFeet<filterSquareFeetMin){
//             filterOut=true;
//         }
//         if(listings[i].squareFeet>filterSquareFeetMax){
//             filterOut=true;
//         }
//         if(listings[i].neighbourhood!=filterNeighbourhood){
//             filterOut=true;
//         }
        
//         if(!listings[i].address.includes(filterAddress)){
//             filterOut=true;
//         }


//         if(filterOut){

//         }else{

//             filteredlistings.push(listings[i]);
//         }
        
//     }
    

//     console.log(filteredlistings);
//     //display filtered listings
//     document.getElementById("display_listings").innerHTML="";
//     for(var i = 0; i<filteredlistings.length;i++){
//         document.getElementById("display_listings").innerHTML+=
//         "Listing ID: "+filteredlistings[i].listingID+": "+
//         "<br>Price: "+filteredlistings[i].price +
//         "<br>Term: "+filteredlistings[i].term+
//         "<br>Public Transit:"+filteredlistings[i].publicTransit+
//         "<br>Parking: "+filteredlistings[i].parking+
//         "<br>Smoking: "+filteredlistings[i].smoking+
//         "<br>Square Feet: "+filteredlistings[i].squareFeet+
//         "<br>Capacity: "+filteredlistings[i].capacity+
//         "<br>Address: "+filteredlistings[i].address+
//         "<br>Neighbourhood: "+filteredlistings[i].neighbourhood+"<br><br>";
//     }
   // constructor(price, term, publicTransit, parking, smoking, squareFeet,  capacity, address, neighbourhood) {
// }



// User Stories 5 and 6



// User Stories 7 and 8 

var RegUserName = ""
$(document).ready(function() {
    $("button").click(function() {
        if( UserInput==UserName) {
            
        }
    })

})



