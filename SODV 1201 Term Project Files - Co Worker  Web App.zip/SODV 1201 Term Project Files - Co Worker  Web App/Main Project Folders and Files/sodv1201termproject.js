/* SODV 1201 Introduction to Web Programming 
SODV 1201 Term Project- Co-Worker Work Spaces and Properties 
 Program designed and coded by: SODV 1201 Group 2: Sasha Greene,  Gurleen Kaur, Paul K Kho, Evan Maclean
 Instructor:                   Dima Marachi
 Due       :     Phase 1   : June 2 2022
                 Phase 2   : June 24 2022 
*/


// Landing Page (Home Page )



// User Story 1 and 3 




// User Story 2 and 4



// User Story 5 and 6



// User Story 7 and 8

