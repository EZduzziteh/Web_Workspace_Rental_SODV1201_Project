var dataSet = [
    ["John Wick", "1221 Queen Avenue", "Thornhill", "200", "true", "true"],
    ["Steve Jobs", "1234 long Street", "Meadowbrook", "600", "true", "false"],
    ["Maia Jules", "342 Aron Way", "Big Hills", "1200", "false", "false"],
    ["Steve Harvey", "1336 King Street", "Remo", "1000", "true", "true"],
    ["Hammond Graves", "2201 Brightwell Road", "Central", "350", "false", "true"],
    ["Laura Reeves", "1216 Queen Avenue", "Thornhill", "356", "true", "true"],
    ["Dan Forrester", "343 Aron Way", "Big Hills", "900", "false", "false"],
    ["Ann Goodman", "1000 Queen Avenue", "Thornhill", "600", "true", "true"],
    
    
];

/*
let listing1 = new Listing1("001", 200, "Daily", true, true, false, 200, 1, "1221 Queen Avenue", "Thornhill" );
let listing2 = new Listing1("002", 1200, "Weekly", false, true, false, 600, 4 , "1234 long Street", "Meadowbrook");
let listing3 = new Listing1("003", 2000, "Monthly", false, false, false, 1200, 8 , "342 Aron Way", "Big Hills");
let listing4 = new Listing1("004", 500, "Weekly", true, true, true, 1000, 6 , "1336 King Street", "Remo");
let listing5 = new Listing1("005", 875, "Weekly", true, false, true, 350, 1 , "2201 Brightwell Road", "Central");
let listing6 = new Listing1("006", 250, "Daily", true, true, false, 356, 3, "1216 Queen Avenue", "Thornhill" );
let listing7 = new Listing1("007", 2200, "Monthly", false, false, false, 900, 6 , "343 Aron Way", "Big Hills");
let listing8 = new Listing1("008", 675, "Daily", true, true, false, 600, 6, "1000 Queen Avenue", "Thornhill" );
*/